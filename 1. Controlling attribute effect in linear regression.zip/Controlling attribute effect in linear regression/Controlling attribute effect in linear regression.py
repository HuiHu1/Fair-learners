# -*- coding: utf-8 -*-
"""
Created on Wed Jun 26 09:49:51 2019
@author: hhu1
"""
from __future__ import print_function
from __future__ import division
from __future__ import unicode_literals
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error
from scipy import optimize
from sklearn.linear_model import LogisticRegression
from sklearn.base import BaseEstimator, ClassifierMixin
from sklearn.metrics import mean_squared_error
from sklearn import preprocessing
#---------------------------------------------------------------------
def sigmoid(x, w):
    s = np.clip(np.dot(w, x), -SIGMOID_RANGE, SIGMOID_RANGE)
    return 1.0 / (1.0 + np.exp(-s))

def predict(X,coef_):
    return np.argmax(predict_proba(X,coef_,c_s_), 1)   

def predict_proba(X,coef_,c_s_):
    n_features_= X.shape[1]
    n_samples_ = X.shape[0]
    if fit_intercept:
        X = np.c_[np.atleast_2d(X)[:, :-n_s_], np.ones(X.shape[0])]
    else:
        X = np.atleast_2d(X)[:, :-n_s_]

        
    coef = coef_.reshape(n_sfv_, n_features_)

    proba = np.empty((X.shape[0], N_CLASSES))
    proba[:, 1] = [np.sum([c_s_[si] *
						   sigmoid(X[i, :], coef[si, :])
						   for si in range(n_sfv_)])
				   / n_samples_
				   for i in range(X.shape[0])]
    proba[:, 0] = 1.0 - proba[:, 1]
    return proba

def init_coef(itype, X, y, s):
    n_features_ = X.shape[1]
    n_samples_ = X.shape[0]
    if itype == 0:
        # clear by zeros
        coef_ = np.zeros(n_sfv_ * n_features_,
                              dtype=np.float)
    elif itype == 1:
        # at random
        coef_= np.random.normal(0,1000,n_sfv_ * n_features_)

    elif itype == 2:
        # learned by standard LR
        coef_ = np.empty(n_sfv_ * n_features_,
                              dtype=np.float)
        coef = coef_.reshape(n_sfv_, n_features_)

        clr = LogisticRegression(C=C, penalty='20',
                                 fit_intercept=False)
        clr.fit(X, y)

        coef[:, :] = clr.coef_
    elif itype == 3:
        # learned by standard LR
        coef_ = np.empty(n_sfv_ * n_features_,
                              dtype=np.float)
        coef = coef_.reshape(n_sfv_, n_features_)

        for i in range(n_sfv_):
            clr = LogisticRegression(C=C, penalty='20',
                                     fit_intercept=False)
            clr.fit(X[s == i, :], y[s == i])
            coef[i, :] = clr.coef_
    return coef_

def loss(coef_, X, y, s, c_s_):
    n_features_ = X.shape[1]
    n_samples_ = X.shape[0]
    coef = coef_.reshape(n_sfv_, n_features_)
    p = np.array([sigmoid(X[i, :], coef[s[i], :])
				  for i in range(n_samples_)])
    q = np.array([np.sum(p[s == si])
				  for si in range(n_sfv_)]) / c_s_
    r = np.sum(p) / n_samples_
	### loss function
    l = np.sum(y * np.log(p) + (1.0 - y) * np.log(1.0 - p))
    f = np.sum(p * (np.log(q[s]) - np.log(r))
		 + (1.0 - p) * (np.log(1.0 - q[s]) - np.log(1.0 - r)))
	# l2 regularizer
    reg = np.sum(coef * coef)
    l = -l + eta * f + 0.5 * C * reg
#        print >> sys.stderr, l
    return l

def grad_loss(coef_, X, y, s, c_s_):
    
    n_features_ = X.shape[1]
    n_samples_ = X.shape[0]
    coef = coef_.reshape(n_sfv_, n_features_)
    l_ = np.empty(n_sfv_ * n_features_)
    l = l_.reshape(n_sfv_, n_features_)

	### constants
    p = np.array([sigmoid(X[i, :], coef[s[i], :])	
			  for i in range(n_samples_)])
    
    dp = (p * (1.0 - p))[:, np.newaxis] * X


    q = np.array([np.sum(p[s == si])
				  for si in range(n_sfv_)]) / c_s_
    dq = np.array([np.sum(dp[s == si, :], axis=0)
				   for si in range(n_sfv_)]) \
				   / c_s_[:, np.newaxis]

    
    r = np.sum(p) / n_samples_
    dr = np.sum(dp, axis=0) / n_samples_

	# likelihood
    for si in range(n_sfv_):
        l[si, :] = np.sum((y.reshape((len(y),1)) - p.reshape((len(p),1)))[s == si] * X[s == si, :],
						  axis=0)
    f1 = (np.log(q[s]) - np.log(r)) \
		 - (np.log(1.0 - q[s]) - np.log(1.0 - r))
    f2 = (p - q[s]) / (q[s] * (1.0 - q[s]))
    f3 = (p - r) / (r * (1.0 - r))
    f4 = f1[:, np.newaxis] * dp \
		+ f2[:, np.newaxis] * dq[s, :] \
		- np.outer(f3, dr)
    f = np.array([np.sum(f4[s == si, :], axis=0)
				  for si in range(n_sfv_)])
    reg = coef
    l[:, :] = -l + eta * f + C * reg

    return l_

def fit(X, y, s, c_s_,ns,itype,**kwargs):
    coef_ = init_coef(1,X, y,s)
    s = np.atleast_1d(np.squeeze(np.array(X)[:, -ns]).astype(int))
    
    if fit_intercept:
        X = np.c_[np.atleast_2d(X)[:, :-ns], np.ones(X.shape[0])]
    else:
        X = np.atleast_2d(X)[:, :-ns]
    coef_ = optimize.fmin_cg(loss, coef_, fprime=grad_loss, args=(X, y, s, c_s_),**kwargs)
    f_loss_ = loss(coef_, X, y, s, c_s_)
    return coef_,f_loss_

if __name__ == '__main__':
    #------------------------------variable definition-----------------------
    EPSILON = 1.0e-5
    SIGMOID_RANGE = np.log((1.0 - EPSILON) / EPSILON)
    C=1
    eta=10
    N_S = 1
    N_CLASSES = 2
    n_s_=1 # the number of sensitive features
    n_sfv_=2 #the number of sensitive feature values.
    n_features_=22 #the number of non-sensitive features
    fit_intercept=True
    penalty='l2'
    minor_type = 0
    f_loss_ = np.inf
    data = np.genfromtxt('creditcarddefault.csv', delimiter=',')
    s_initial = data[:,22]
    label_initial=data[:,23]
    data = preprocessing.scale(data[:,0:24])
    data[:,22]= s_initial
    data[:,23]= label_initial
    sample = data[:,0:-1]
    label = data[:,23]
    [n,p] = sample.shape
    sample_train = sample[0:int(0.75*n),:]
    label_train = label[0:int(0.75*n)]
    sample_test = sample[int(0.75*n):,:]
    label_test = label[int(0.75*n):]
    [x1,y1]=sample_train.shape
    s = sample_train[:,22]
    s1 = sample_test[:,22]
    c_s_ = np.array([np.sum(s == si).astype(np.float)
						  for si in range(n_sfv_)]) 
    coef_,f_loss_ =fit(sample_train[:,0:23],label_train,s,c_s_,ns=N_S,itype=0) #looking for optimal coff vector
    pred = predict(sample_test[:,0:23],coef_) #prediction
    test_error=mean_squared_error(label_test, pred) 
    print("testing error is:\n",test_error)
    #---------------------------fairness: SP----------------------
    x2=len(pred)
    count_0 = 0
    count_1 = 0
    for i in range(x2):
        if(pred[i]==1 and s1[i]==1):
            count_0 = count_0+1
        if(pred[i]==1 and s1[i]==0):
            count_1 = count_1+1
    SP = abs(count_0/x2-count_1/x2)
    print("fairness is:\n",SP)    